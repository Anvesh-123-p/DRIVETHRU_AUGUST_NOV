import SideBar from "../../component/SideBar/SideBar";
import styles from "./ViewRounds.module.css"
import Header from "../../component/Header/Header"
import Tabs from 'react-bootstrap/Tabs';
import { Modal,ModalHeader,ModalBody } from 'reactstrap';
import { useState,useEffect } from "react";
import { resolvePath, useLocation } from 'react-router-dom'
import axios from "axios";
import { Fragment } from "react";
import { Box,CustomTabPanel } from "@mui/material";
import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import TabPanel from '@mui/lab/TabPanel';
import { useNavigate } from "react-router-dom";
import {
  CircularProgress
  } from "@mui/material";


 


const ViewRounds=()=>{
  const location=useLocation()
  const propsdata=location.state
  let id=propsdata.state1
  const navigate=useNavigate();

  console.log(propsdata.state1)
  const[showForm,setShowForm]=useState(false)
  const[data,setdata]=useState('')
  const[estu,setestu]=useState([])
  const[round,setround]=useState([])
  const [data2,setdata2]=useState([])
  const [value, setValue] =useState('1');
  const[u,setu]=useState([])
 

  
  

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  
 
 
  let selected=[]
  let userurl="http://127.0.0.1:8000/api/users/"

  let roundurl="http://127.0.0.1:8000/api/rounds/"
  

   
  const handleSubmit=(e)=>{
   let body={
      "selected_students":selected
    }
    console.log(e.target.value)
    console.log(body)
    

    axios.patch(roundurl,body,{
    
      
      params:{
        "drive_id": id,
        "number": e.target.value
    }
     }).then((response )=>{
      console.log(response)
      if(response.status==200){
        alert('success')
        
      }
     })
     
     
    


  }

  
  
  const handlechange=(e)=>{
    
    if(e.target.checked==true){
      selected.push(parseInt(e.target.value))

    }else{
      selected = selected.filter(item => item !== parseInt(e.target.value))
    }
    console.log(selected)
    console.log(e.target.checked)
    console.log(e.target.value)
    
  }
 
  function getlist(es){
    let st='a'
    if(es.length!=0){
      st=''
    }
    for (let i=0; i<es.length;i++){
      if(i!=es.length-1){
        st=st+es[i]+','
      }
      else{
        st=st+es[i]

      }

    }
    console.log(st)
    axios.get(userurl,{
      params:{
          "ids": st
      }}).then(
          (response)=>{
            console.log(response.data.data.length)
            if(response.data.data.length==0){
              console.log("fgvhbjnmk")
              setestu('a')
            }
            else{

            setestu(response.data.data)
            }
           
            
          }


      )


    
    
  }
  const handleround=(n)=>{
    setround([])

    axios.get(roundurl,{
              params:{
                  "drive_id": id,
                  "number":n-1
              }}).then(
                  (response)=>{
                    if(response.data.data[0].selected_students.length==0){
                      setround('a')
                    }else{
                      console.log(response.data.data[0].selected_students)
                        setround(response.data.data[0].selected_students)
                    }
                   
                      
                      
                     
                      
                      
                    
                  }
    
    
              )
         

   
  }
 
  
  

  let logurl="http://127.0.0.1:8000/api/drives/"
    useEffect(() => {
        axios.get(logurl,{
            params:{
                "drive_id": id
            }}).then(
                (response)=>{
                    console.log(response.data.data)
                    setdata(response.data.data)
                    getlist(response.data.data.enrolled_students)
                    setdata2(response.data.data2)
                  
                }
  
  
            )
       
      
    
    },[]);


  const completed=(e)=>{
    let body={
      "status": "CO"
    } 

    axios.patch(logurl,body,{
    
      
      params:{
        "id": id   
    }
     }).then((response )=>{
      console.log(response)
      if(response.status==200){
        alert('Success')
      }
      setTimeout(() => {
        navigate('/home');
        }, 1000);
     })
    }
     

     
    


  



  
    

  const getuser=(id)=>{
      axios.get(userurl,{
        params:{
            "id": id
        }}).then(
            (response)=>{
                console.log(response.data.data)
                setu(response.data.data)
               
              
                
                
              
            }


        )
   

    }
    console.log(data.num_of_rounds)

 


   
    
  



  const handleClose=()=>{
    setShowForm(false)
  }
  
    return(
    
        <div>
        <Header/>
        <SideBar/>
        <div className={styles.contents}>
        
        <h3>{data.company_name} </h3> 
         <h5> CTC:{data.ctc}</h5>
         
       
  
    <Box sx={{ width: '100%', typography: 'body1' }}>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <TabList onChange={handleChange} aria-label="lab API tabs example">
            <Tab label="Round 1" value="1"  /> 
            {data2.map((x)=>(
              
              <Tab label={`Round ${x}`} value={x.toString()}  onClick={()=>{
              handleround(x)
            }}/>
            ))}
            
           
           
          </TabList>

        </Box>
        
        <TabPanel value="1">  
        <div className={styles.tablediv}>
      <table class="table table-striped table-hover">
    <thead className={styles.thead}>
    <tr>
      <th scope="col"></th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th><select  className={`border-0 ${styles.drop}`} >
                <option defaultValue value="v"className={styles.drop}>Department</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electrical </option>
                <option value="MECH">Mechanical</option>
                <option value="CIVIL">Civil</option>
                <option value="EEE">EEE</option>
                </select>
      </th>
      <th scope="col">Percentage</th>
      <th scope="col">Resume Link</th>
    </tr>
  </thead>
  {estu.length==0 && <div id={styles.loading}><CircularProgress /></div>}
  
  
  {estu=='a'?<p>No Enrolled Students</p>:estu.map((x)=>(
     <tbody>
    <tr>
    <input class="form-check-input" type="checkbox" onChange={handlechange}
    
    value={x.id} id="flexCheckDefault"/>
      
      <td scope="row">{x.first_name}</td>
      <td>{x.email}</td>
      <td>{x.dept}</td>
      <td>{x.percentage}</td>
      <td>{x.resume_link}</td>
    </tr>
    </tbody>
    
 
  ))} 

 
</table>
<div className={styles.button}>

      <button type="button" onClick={ handleSubmit} value={1} className={` btn btn-sm ${styles.btn}`}>Submit</button>
      </div>
</div>
</TabPanel>
    {data2.map((y)=>(
      <TabPanel value={y.toString()}>
      <div className={styles.tablediv}>
      <table class="table table-striped table-hover">
  <thead className={styles.thead}>
  <tr>
    <th scope="col"></th>
    <th scope="col">Name</th>
    <th scope="col">Email</th>
    <th><select  className={`border-0 ${styles.drop}`} >
              <option defaultValue value="v"className={styles.drop}>Department</option>
              <option value="CSE">Computer Science</option>
              <option value="ECE">Electrical </option>
              <option value="MECH">Mechanical</option>
              <option value="CIVIL">Civil</option>
              <option value="EEE">EEE</option>
              </select>
    </th>
    <th scope="col">Percentage</th>
    <th scope="col">Resume Link</th>
  </tr>
</thead>

{round.length==0 && <div id={styles.loading}><CircularProgress /></div>}
        {round=='a'?<p>hello</p>:round.map((u)=>(
           <tbody>
           <tr>
           <input class="form-check-input" type="checkbox" onChange={handlechange}
           
           value={u.id} id="flexCheckDefault"/>
             
             <td scope="row">{u.first_name}</td>
             <td>{u.email}</td>
             <td>{u.dept}</td>
             <td>{u.percentage}</td>
             <td>{u.resume_link}</td>
           </tr>
           </tbody>

          
        ))}
        </table>
        <div className={styles.button}>
        
        {y==data.num_of_rounds&& <button type="button"  onClick={completed} value={y} className={` btn btn-sm ${styles.btn}`}>Completed</button>}
        {/* <Modal size='md'
             isOpen={showForm}
            toggle={()=>setShowForm(true)}>
            <ModalHeader
            toggle={()=>setShowForm(false)}> 
            Add Drive   
            </ModalHeader>
        <ModalBody>
          <h6>On sumit this , Next sequent round starts and this round gets marked completed.</h6>
          <h6>Are you Sure?</h6>
          <button type="button" onClick={handleClose} className="btn btn-sm">Cancel</button>
          <button type="button" onSubmit={handleSubmit} className={` btn btn-sm ${styles.btn}`}>Submit</button>
        </ModalBody>
        </Modal> */}
    <button type="button" onClick={ handleSubmit} value={y} className={` btn btn-sm ${styles.btn}`}>Submit</button>
    </div>
    </div>
      </TabPanel>
    ))}
        
       
      </TabContext>
    </Box>
  


    

      
      </div>
        </div>
    )
}

export default ViewRounds;