import React from "react";


const Placement = () => {
    return (
        <div>
            <h1> Placement </h1></div>
    );
};

export default Placement;