import React from "react";
import 'bootstrap/dist/css/bootstrap.css';
import styles from"./ViewStudents.module.css";
import SideBar from "../../component/SideBar/SideBar";
import Header from "../../component/Header/Header";
import { useState,useEffect } from "react";
import axios from "axios";
import {BiSearch} from 'react-icons/bi'




const ViewStudents = () => {
    const[table,settable]=useState([])
    const[dept,setdept]=useState(['CSE','ECE','EEE','MECH','CIVIL','x'])
    const[Search,setSearch]=useState('')
    
   
   
  
    let url="http://127.0.0.1:8000/api/users/"
    useEffect(() => {
      axios.get(url).then((response)=>{
        settable(response.data.data)
  
      })
    },[]);

const filter=(e)=>{


  if(e.target.value==='v'){
    setdept(['CSE','ECE','EEE','MECH','CIVIL','x'])
  }
  else{
console.log(e.target.value)
setdept([e.target.value])
console.log(dept)
  }
}

const search=(e)=>{
  setSearch(e.target.value)
  console.log(Search)

}

const Departmentfilter=(x)=>{
  if(Search != ''){
    
    return (x.first_name.toLowerCase()== Search.toLowerCase()) 
    
  }
  else{
    return x
  }
}

  


  
    return (
      <div>
        <Header/>
        <SideBar/>
        <div className={styles.container}>
        <div className={styles.search}>
        <form class="container d-flex">
           <input class="form-control me-2" type="search" placeholder="Search" 
           onChange={search} aria-label="Search"/>
           <BiSearch className="fs-1"/>
          </form>
        </div> 
         
            <div className={styles.tablediv}>
            <table className="table table-striped table-hover">
  <thead className={styles.thead}>
    <tr>
      <th scope="col">Name</th>
      <th scope="col">
        <select  className={`border-0 ${styles.drop}`} onChange={filter}>
                <option defaultValue value="v"className={styles.drop}>Department</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electrical </option>
                <option value="MECH">Mechanical</option>
                <option value="CIVIL">Civil</option>
                <option value="EEE">EEE</option>
                </select>
                </th>
      <th scope="col">Percentage</th>
      <th scope="col">Resume Link</th>
      <th scope="col">Offer Letters Received</th>
    </tr>
  </thead>



 
    {table.filter((x)=>(
     dept.includes(x.dept)
    )).filter((x)=>(
      Departmentfilter(x)
    ))
    .map((t)=>(
     <tbody>
      <tr >
      <th scope="row">{t.first_name}</th>
      <td>{t.dept}</td>
      <td>{t.percentage}</td>
      <td>{t.resume_link}</td>
      <td>5</td>
    </tr>
    </tbody>
    )
      )}
  
</table>
</div>
            
            
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    </div>
    );
};

export default ViewStudents;