import React, { useState , useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import {BsPersonCircle} from "react-icons/bs"
import { Modal,ModalHeader,ModalBody } from 'reactstrap';
import Dropdown from 'react-bootstrap/Dropdown';
import axios from "axios";
import { useNavigate } from "react-router-dom";

import styles from"./HodHeader.module.css"



const HodHeader =(props)=>{  
    const[studata,setstudata]=useState('')
    let navigate=useNavigate()

    let logurl="http://127.0.0.1:8000/api/users/"
    useEffect(() => {
      if(localStorage.getItem('token')!=null){
        const localdata = JSON.parse(localStorage.getItem("token"));
        console.log(localdata.id)
        axios.get(logurl,{
            params:{
                "id":localdata.id
            }}).then(
                (response)=>{
                    console.log(response.data.data.first_name)
                    setstudata(response.data.data)
                }
  
  
            )
  
       
      }
    
    },[]);

    const logout=()=>{
        localStorage.clear()
        setTimeout(() => {
            navigate('/login');
            }, 2000);

    }
  

    return(
        <div className={styles.maindiv}> 
            
        
        <header >
            <nav className="navbar navbar-expand-lg navbar-light bg-light shadow bg-white rounded">
                <div className="container-fluid">
                  <a className="navbar-brand" href="#">Hod Dashboard</a>
                  <Dropdown>
                        <Dropdown.Toggle  id={styles.dropdownbasic}>
                            {studata.first_name}
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                            <Dropdown.Item href="#/action-1">Edit Profile</Dropdown.Item>
                            <Dropdown.Item onClick={logout}>Logout</Dropdown.Item>
                        </Dropdown.Menu>
                 </Dropdown>
                </div>


            </nav>
        </header>
       
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    </div>

    );
};

export default HodHeader;