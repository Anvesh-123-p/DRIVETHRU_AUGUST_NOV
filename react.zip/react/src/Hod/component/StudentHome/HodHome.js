import HodHeader from "../Header/HodHeader";
import HSideBar from "../Sidebar/HSideBar";
import React from "react";
import 'bootstrap/dist/css/bootstrap.css';
import styles from './HodHome.module.css'
import { Pagination } from "@mui/material";
import { useState,useEffect } from "react";
import axios from "axios";
import { BiSearch } from "react-icons/bi";
import {
  CircularProgress
  } from "@mui/material";
import {Fragment} from 'react'





const HodHome=()=>{
  let c=0
  const[d,setd]=useState([])
  const[Search,setSearch]=useState('')
  const[currentpage,setcurrentpage]=useState(1)
  const[numofcard,setnumofcard]=useState(9)
  const[n,setn]=useState(1)
 
  const[w,setw]=useState([])
  const[s,sets]=useState(false)
  const[load,setload]=useState(false)
  
 

  let url="http://127.0.0.1:8000/api/drives/"
  useEffect(() => {
    setd([])
    setw([])
    axios.get(url).then((response)=>{
      setd(response.data.data.reverse())

      setn(Math.ceil(response.data.data.length/9))

      let li=numofcard*currentpage
      let fi=li-numofcard
      setw(response.data.data.slice(fi,li))
      
    
      
    })
  },[currentpage,load]);
  console.log(n)
 
  

  const pd=()=>{
    let pages=[]
    for(let i=1;i<=n;i++){
      pages.push(i)
    }
    
    return pages
  }

  

  const reload=(o)=>{
    setload(true)
    console.log("load")
  }
  

   
    return(
        <div>
           <HodHeader/>
        <HSideBar/>

      
           
  
         
       
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossOrigin="anonymous"></script>
  
        </div>
    )
}

export default HodHome;