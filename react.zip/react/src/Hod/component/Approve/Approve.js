import HodHeader from "../Header/HodHeader";
import HSideBar from "../Sidebar/HSideBar";
import React from "react";
import 'bootstrap/dist/css/bootstrap.css';
import styles from './Approve.module.css'
import { Pagination } from "@mui/material";
import { useState,useEffect } from "react";
import axios from "axios";
import { BiSearch } from "react-icons/bi";
import {
  CircularProgress
  } from "@mui/material";
import {Fragment} from 'react'

const Approve=()=>{

    return(
        <div className= {styles.contents}>

        </div>
    )

}

export default Approve;