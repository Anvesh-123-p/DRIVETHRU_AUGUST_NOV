import React from "react";
import{Link} from 'react-router-dom'
import styles from './StudentCard.module.css'
import { useState } from "react";
import axios from "axios";



const StudentCard=(props)=>{
  const localdata = JSON.parse(localStorage.getItem("token"));
  console.log(props)
  
  const round={
  "state1": props.id
}


let enrollurl="http://127.0.0.1:8000/api/drives/"
const[y,sety]=useState([1,2,3,4,5])




const handleClick=()=>{
   console.log(props)
   
       
  let body={

    "enrolled_students":[localdata.id]
    
  }
  console.log(body)
  axios.patch(enrollurl,body,{params:{
    "id":props.id 
  }}).then(
    (response)=>{
        props.loadhandler(5)
      

    }
  )



}

    

return(
  
  <div className={`card ${styles.card}`} >
              <div className="card-body">
                <h3 className="card-title">{props.title}</h3>
                  <p className="card-text ">{props.info}</p>
                  <h6 className="card-text">CTC:{props.ctc}</h6>
                  <h6 className="card-text ">Eligibility:{props.elig}</h6> 
                  {(props.enrolled_students.includes(localdata.id) && props.status=="NS") ? <Link to="#" className="btn text-white"   id= {styles.btn}>Enrolled</Link>
                  :(props.status=="NS"&& <Link to="#" className="btn text-white" onClick={handleClick} id= {styles.btn}>Enroll</Link>)}

                  {props.status=="IP" && <Link to="/progress" state={round}> View Status</Link>}

                  
                  
              </div>   
  </div>
 
)
}

export default StudentCard;