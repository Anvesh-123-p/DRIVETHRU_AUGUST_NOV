import StudentHeader from "../Header/StudentHeader";
import SSideBar from "../Sidebar/SSideBar";
import React from "react";
import 'bootstrap/dist/css/bootstrap.css';

import styles from './ViewEnrolled.module.css'


const ViewEnrolled=()=>{
    return(
     <div>
        <StudentHeader />
        <SSideBar/>
        <div className={styles.contents}>
            <div className={styles.tablediv}>
      <table class="table table-striped table-hover">
    <thead className={styles.thead}>
    <tr>
      <th scope="col">Company Name</th>
      <th scope="col">Status</th>
      <th scope="col">CTC</th>
      <th scope="col">Offer Letter</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td scope="row">XYZ</td>
      <td>Round 1</td>
      <td>7</td>
      <td>njdwufhwhf</td>
    </tr>
    <tr>
      <td scope="row">XYZ</td>
      <td>Round 1</td>
      <td>7</td>
      <td>njdwufhwhf</td>
    </tr>
    <tr>
      <td scope="row">XYZ</td>
      <td>Round 1</td>
      <td>7</td>
      <td>njdwufhwhf</td>
    </tr>
    <tr>
      <td scope="row">XYZ</td>
      <td>Round 1</td>
      <td>7</td>
      <td>njdwufhwhf</td>
    </tr>
    </tbody>
    </table>
        </div>
    </div>

     </div>
    )
}

export default ViewEnrolled;