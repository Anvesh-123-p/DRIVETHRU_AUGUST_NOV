import 'bootstrap/dist/css/bootstrap.css';
import{Link} from 'react-router-dom'

import home from '../../../Assests/home.svg'
import eye from '../../../Assests/eye.svg'
import edit from '../../../Assests/edit.svg'
import log from '../../../Assests/logout.svg'
import styles from "./SSideBar.module.css"
import { useNavigate } from "react-router-dom";


const SSideBar =()=>{  

 

   

    return(
       <div>
            <div className= {styles.sidebar}>

                <div className='top_section'>
                    <h2>Hello!</h2>
                    <h2>Welcome Back</h2>   
                </div>
                <div className={styles.contentscontainer}>
                    <ul className={styles.ui}>
                        <li className={styles.li}>
                       <img src={home}/><Link className={styles.a} to="/studenthome">Home</Link>
                        </li>

                        <li className={styles.li}>
                        <img src={eye}/><Link className={styles.a} to="/studentenrolled">View Enrolled</Link>
                        </li>

                        <li className={styles.li}>
                        <img src={edit}/> <Link className={styles.a} to="/studentprofile">Edit Profile</Link>
                        </li>

                        <li className={styles.li}>
                        <img  id={styles.log} src={log}/><Link   to="" className={styles.a} id={styles.logout}> Logout</Link>
                        </li>

                    </ul>
                </div>

               
            
            
            </div>
            <div className={styles.side}>
                    <ul className={styles.ui}>
                        <li className={styles.li}>
                       <Link to="/studenthome"><img src={home}/></Link>
                        </li>

                        <li className={styles.li}>
                        <Link  to="//studentenrolled"><img src={eye}/></Link>
                        </li>

                        <li className={styles.li}>
                         <Link to="/studentprofile"><img src={edit}/></Link>
                        </li>

                        <li className={styles.li}>
                        <Link   to="/placement"><img  id={styles.log} src={log}/></Link>
                        </li>

                    </ul>
                </div>

           
         </div>


           
    );
    
};

export default SSideBar;