import styles from './StudentProgress.module.css'
import SSideBar from '../Sidebar/SSideBar';
import StudentHeader from '../Header/StudentHeader';
import { useLocation } from 'react-router-dom';
import { useState,useEffect } from 'react';
import axios from "axios";
import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import CircularProgress, {
  circularProgressClasses,
} from '@mui/material/CircularProgress';
import LinearProgress, { linearProgressClasses } from '@mui/material/LinearProgress';


const StudentProgress=()=>{
  const location=useLocation()
  const propsdata=location.state
  let id=propsdata.state1
  const [data2,setdata2]=useState([])
  const [prog,setprog]=useState('')
  const [data3,setdata3]=useState()

  const BorderLinearProgress = styled(LinearProgress)(({ theme }) => ({
    height: 15,
    borderRadius: 5,
    [`&.${linearProgressClasses.colorPrimary}`]: {
      backgroundColor: theme.palette.grey[theme.palette.mode === 'light' ? 200 : 800],
    },
    [`& .${linearProgressClasses.bar}`]: {
      borderRadius: 5,
      backgroundColor: theme.palette.mode === 'light' ? '#2E3977' : '#308fe8',
    },
  }));


console.log(id)
let logurl="http://127.0.0.1:8000/api/drives/"
    useEffect(() => {
        axios.get(logurl,{
            params:{
                "id": id
            }}).then(
                (response)=>{
                    setprog(response.data.data)
                    setdata2(response.data.data2)
                    setdata3(response.data.width)
                  
                }
  
  
            )
       
      
    
    },[]);
  return(
    <div>
      <StudentHeader/>
      <SSideBar/>
    <div className={styles.contents}>
      <h1>{prog.company_name}</h1>
<div className={styles.st}> 
  <p>Round 1</p>
 {data2.map((x)=>(
  <p>{`Round ${x}`}</p>
 ))} 


</div>

<Box sx={{ flexGrow: 1 }}>
      <BorderLinearProgress variant="determinate" value={data3} />
    </Box>



<p className={styles.desc}>{prog.description}</p>
<p className={styles.desc2}>{prog.jd_link} </p>
<p className={styles.desc2}><b>status of selection :</b></p>

    </div>
    </div>
  )
}

export default StudentProgress;