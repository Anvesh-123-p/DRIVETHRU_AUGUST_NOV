import React from "react"

const Pagination=()=>{
    return(
       
            
                    
                    <li class="page-item"><a class="page-link">1</a></li>  
                    
                    
    
    )
}

export default Pagination;