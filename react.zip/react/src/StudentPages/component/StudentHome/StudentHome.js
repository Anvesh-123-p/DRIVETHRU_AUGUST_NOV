import StudentHeader from "../Header/StudentHeader";
import SSideBar from "../Sidebar/SSideBar";
import React from "react";
import 'bootstrap/dist/css/bootstrap.css';
import styles from './StudentHome.module.css'
import { Pagination } from "@mui/material";
import { useState,useEffect } from "react";
import axios from "axios";
import StudentCard from "../StudentCard/StudentCard"

import { BiSearch } from "react-icons/bi";
import {
  CircularProgress
  } from "@mui/material";
import {Fragment} from 'react'





const StudentHome=()=>{
  let c=0
  const[d,setd]=useState([])
  const[Search,setSearch]=useState('')
  const[currentpage,setcurrentpage]=useState(1)
  const[numofcard,setnumofcard]=useState(9)
  const[n,setn]=useState(1)
 
  const[w,setw]=useState([])
  const[s,sets]=useState(false)
  const[load,setload]=useState(false)
  
 

  let url="http://127.0.0.1:8000/api/drives/"
  useEffect(() => {
    setd([])
    setw([])
    axios.get(url).then((response)=>{
      setd(response.data.data.reverse())

      setn(Math.ceil(response.data.data.length/9))

      let li=numofcard*currentpage
      let fi=li-numofcard
      setw(response.data.data.slice(fi,li))
      
    
      
    })
  },[currentpage,load]);
  console.log(n)
 
  

  const pd=()=>{
    let pages=[]
    for(let i=1;i<=n;i++){
      pages.push(i)
    }
    
    return pages
  }

  

  const reload=(o)=>{
    setload(true)
    console.log("load")
  }
  

   
    return(
        <div>
           <StudentHeader/>
        <SSideBar/>

        <div className={styles.search}>
        <form class="container d-flex">
           <input class="form-control me-2 border-dark" type="search" placeholder="Search" 
           onChange={(e)=>{
            setSearch(e.target.value)
            sets(true)
           }} aria-label="Search"/>
           <BiSearch className="fs-1"/>
          </form>
        </div> 
        <div className={styles.contents}>
         
          {d.length===0&&
          <div id={styles.loading}><CircularProgress /></div>}


                {s ? (d.length>0 &&   d.filter((d)=>{
              if(Search==""){
                return d
              }else if(d.company_name.toLowerCase().includes(Search.toLowerCase())){
                return d
              }

                }).map((x)=>(
               
               <StudentCard title={x.company_name}  enrolled_students={x.enrolled_students} info={x.description} ctc={x.ctc} elig={x.eligible_percentage} status={x.status}  id={x.id} loadhandler={reload}/>
             
               
              
             ))):
             (
              w.map((x)=>(
               
                <StudentCard title={x.company_name} enrolled_students={x.enrolled_students} info={x.description} ctc={x.ctc} elig={x.eligible_percentage} status={x.status} loadhandler={reload} id={x.id}/>
              
                
               
              ))
             )}
                 
                {w.length!=0 && 
                 <nav aria-label={`Page navigation example ${styles.pagination}`}>
                  <ul class="pagination">
                    <li class="page-item">

                      <a class="page-link" onClick={()=>{
                        setcurrentpage(currentpage-1)
                      }

                      }  aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                        <span class="sr-only">Previous</span>
                      </a>
                    </li>
                    
                     {pd().map(
                      (x)=>(
                        
                        <li class="page-item"onClick={()=>{
                          setcurrentpage(x)
                        }} ><a class="page-link">{x}</a></li> 
                        
                      )
                      
                     )}
                    {/* <li class="page-item"onClick={()=>{
                      setcurrentpage(1)
                    }} ><a class="page-link">1</a></li>  
                     <li class="page-item"onClick={()=>{
                      setcurrentpage(2)
                    }} ><a class="page-link">2</a></li>  
                     <li class="page-item"onClick={()=>{
                      setcurrentpage(3)
                    }} ><a class="page-link">3</a></li>    
                    <li class="page-item"onClick={()=>{
                      setcurrentpage(4)
                    }} ><a class="page-link">4</a></li>  
                    <li class="page-item"onClick={()=>{
                      setcurrentpage(5)
                    }} ><a class="page-link">5</a></li>  
                    <li class="page-item"onClick={()=>{
                      setcurrentpage(6)
                    }}><a class="page-link">6</a></li>   */}
                    <li class="page-item">
                    <a class="page-link" onClick={()=>{
                        setcurrentpage(currentpage+1)
                      }

                      } aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                        <span class="sr-only">Next</span>
                      </a>
                    </li>
                  </ul>
                </nav>}
         
         
        
           
        </div>
         
       
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossOrigin="anonymous"></script>
  
        </div>
    )
}

export default StudentHome;