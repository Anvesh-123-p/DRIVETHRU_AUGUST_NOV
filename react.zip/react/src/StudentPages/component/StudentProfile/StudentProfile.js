import React from "react";
import 'bootstrap/dist/css/bootstrap.css';
import styles from './StudentProfile.module.css'
import StudentHeader from "../Header/StudentHeader";
import SSideBar from "../Sidebar/SSideBar";
import { useState,useEffect } from "react";
import axios from "axios";

const StudentProfile=()=>{

  const[prof,setprof]=useState('')
  const[isDisabled,setisDisbled]=useState(true)
  const[dept,setdept]=useState('')
  
  
  

  let profurl="http://127.0.0.1:8000/api/users/"
    useEffect(() => {
      if(localStorage.getItem('token')!=null){
        const localdata = JSON.parse(localStorage.getItem("token"));
        console.log(localdata.id)
        axios.get(profurl,{
            params:{
                "id":localdata.id
            }}).then(
                (response)=>{
                    
                    console.log(response.data.data.first_name)
                    setprof(response.data.data)
                }
  
  
            )
  
       
      }
    
    },[]);

   

   const handleSubmit=(e)=>{
    const localdata = JSON.parse(localStorage.getItem("token"));
    let url="http://127.0.0.1:8000/api/users/"
    const body={
      "first_name": prof.first_name,
      "last_name": prof.last_name,
      "aadhar_number": prof.aadhar_number,
      "dept": prof.dept,
      "percentage": prof.percentage,
      "email": prof.email,
      "mobile_number": prof.mobile_number,
      "resume_link": prof.resume_link

      

     }
     console.log(body)
     console.log(localdata.id)
    axios.patch(url,body,{
    
      
      params:{
        "id":localdata.id
    }
     }).then((response )=>{
      console.log(response)
      if(response.status==200){
        alert('success')

      }else if(response.status!=200){
        alert('Error')
      }

     })
e.preventDefault();
setisDisbled(true)

 
}



  
    
    
   

    const handleclick=(e)=>{
      setisDisbled(false)
      e.preventDefault();


    }

   

  

   const Department=(e)=>{
    setDept(e.target.value)
  }
    return(
      <div>
        <StudentHeader/>
        <SSideBar/>
        <div className={styles.container}>
            
              <h1 className={styles.h1}>edit profile</h1>
            
                <form className="row" onSubmit={(e)=>{handleSubmit(e)}}> 
            <div className='row'>
            <div className="col-lg-5 ">
                <label htmlFor="inputname" className="form-label">First Name</label>
                <input type="text"
                placeholder="First Name"
                 className="form-control border border-dark"
                  onChange={(e)=>{
                    setprof({...prof,first_name:e.target.value})

                }} 
                disabled={isDisabled} 
                value={prof.first_name}  
                id="inputname"/>
            </div>
            <div className="col-lg-5 ">
                <label htmlFor="inputname" className="form-label">Last Name</label>
                <input type="text" 
                className="form-control border border-dark" 
                value={prof.last_name} 
                onChange={(e)=>{
                  setprof({...prof,last_name:e.target.value})
              }}
                disabled={isDisabled} 
                placeholder='Name' 
                id="inputname"/>
            </div>
            
            
            <div className="col-lg-5 ">
              <label htmlFor="exampleInputEmail1"   className="form-label" >Email</label>
              <input type="email" 
               onChange={(e)=>{
                setprof({...prof,email:e.target.value})
            }}
            className="form-control border border-dark" value={prof.email} disabled={isDisabled}  placeholder="Email" id={styles.exampleInput}  aria-describedby="emailHelp"/>
            </div>
            
            <div className="col-lg-5 ">
              <label htmlFor="exampleInputEmail1"   className="form-label" >Mobile Number</label>
              <input type="text" 
                onChange={(e)=>{
                  setprof({...prof,mobile_number:e.target.value})
              }}
              className="form-control border border-dark" value={prof.mobile_number} disabled={isDisabled}  placeholder='Mobile Number' id={styles.exampleInput}  aria-describedby="emailHelp"/>
            </div>
           
            <div class="col-lg-5 ">
              <label htmlFor="percentage" class="form-label">Percentage</label>
              <input type="text" class="form-control border border-dark" 
                onChange={(e)=>{
                  setprof({...prof,percentage:e.target.value})
              }}
              value={prof.percentage} disabled={isDisabled} placeholder="Percentage"/>
            </div>
           <div class="col-lg-5 ">
              <label htmlFor="percentage" class="form-label">Aadhar Number</label>
              <input type="text" class="form-control border border-dark" 
                onChange={(e)=>{
                  setprof({...prof,aadhar_number:e.target.value})
              }}
              value={prof.aadhar_number} disabled={isDisabled}  placeholder="Percentage"/>
            </div>
            
           {isDisabled==true?
           <div class="col-lg-5 ">
              <label htmlFor="percentage" class="form-label">Department</label>
              <input type="text" class="form-control border border-dark" value={prof.dept} disabled={isDisabled}  placeholder="Department"/>
            </div>:
            <div class="col-lg-5 ">
                <label htmlFor="inputState" className="form-label ">Department</label>
                <select id="inputState" onChange={(e)=>{Department(e)}} className="form-select border border-dark">
                <option defaultValue>Department</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electrical </option>
                <option value="MECH">Mechanical</option>
                <option value="CIVIL">Civil</option>
                <option value="EEE">EEE</option>
                </select>
                
            </div>} 
            <div class="col-lg-5 ">
              <label htmlFor="percentage" class="form-label">Resume Link</label>
              <input type="text" class="form-control border border-dark" 
                onChange={(e)=>{
                  setprof({...prof,resume_link:e.target.value})
              }} value={prof.resume_link} disabled={isDisabled} placeholder="Percentage"/>
            </div>
            </div>

              <div>
            <div className="col-lg-5">
            <button type="edit"  className="btn text-black" id={styles.cancel} onClick={(e)=>{handleclick(e)}}>Edit</button>
            <button type="submit"  className="btn text-white" id={styles.save}>Save</button>
            </div>
            </div>
            
            
            
           
          
            </form>

        </div>
        </div>
        
    )
}

export default StudentProfile;