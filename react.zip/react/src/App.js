import React, {useState} from 'react';
import './App.css';
import { BrowserRouter as Router,Routes , Route, BrowserRouter } from 'react-router-dom';
import Home from './pages/Home/Home';
import Placement from './pages/Placement/Placement'
import ViewStudents from './pages/ViewStudents/ViewStudents';
import './component/Header/Header';

import { Fragment } from 'react';
import Login from './component/Login/Login'
import SignUp from './component/Signup/SignUp';
import ViewRounds from './pages/ViewRounds/ViewRounds';
import StudentProfile from './StudentPages/component/StudentProfile/StudentProfile';
import ViewEnrolled from './StudentPages/component/ViewEnrolled/ViewEnrolled';
import StudentHome from './StudentPages/component/StudentHome/StudentHome';
import StudentProgress from './StudentPages/component/StudentProgress/StudentProgress';
import ForgetPassword from './component/ForgetPassword/ForgetPassword';
import PrivateRoute,{Type} from './component/PrivateRoute';
import SSideBar from './StudentPages/component/Sidebar/SSideBar';
import HodHome from './Hod/component/StudentHome/HodHome';
import HodHeader from './Hod/component/Header/HodHeader';
import Approve from './Hod/component/Approve/Approve'






function App() {

  
  
  
  return (
    
   <Router>
    <div className='App'>
    <Approve/>

     <Fragment>
        <Routes>
          <Route path="/login" element={<Login/>}/>
          <Route path="/signup" element={<SignUp/>}/> 
          <Route path="/forgetpassword" element={<ForgetPassword/>}/>
          <Route element={<Type/>}>
            <Route path="/home" element={<Home/>} exact/>
            <Route path="/viewstudents" element={<ViewStudents/>}/>
            <Route path="/placement" element={<Placement/>}/> 
            <Route path="/viewround" element={<ViewRounds/>}/>  
          </Route>
          <Route element={<PrivateRoute/>}>
          <Route path="/progress" element={<StudentProgress/>}/>
            <Route path="/studentprofile" element={<StudentProfile/>}/>
            <Route path="/studentenrolled" element={<ViewEnrolled/>}/>
            <Route path="/studenthome" element={<StudentHome/>}/>
          </Route>
        </Routes>
      </Fragment>
        </div>
   </Router>
   
  );
}




export default App;
