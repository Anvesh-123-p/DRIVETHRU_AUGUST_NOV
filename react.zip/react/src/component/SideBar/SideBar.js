
import 'bootstrap/dist/css/bootstrap.css';
import{Link} from 'react-router-dom'

import home from '../../Assests/home.svg'
import eye from '../../Assests/eye.svg'
import place from '../../Assests/placement.svg'
import log from '../../Assests/logout.svg'
import styles from "./SideBar.module.css"
import { useNavigate } from "react-router-dom";


const SideBar =()=>{  
  let navigate=useNavigate()
 
    const logout=()=>{
        localStorage.clear()
        setTimeout(() => {
            navigate('/login');
            }, 2000);

    }
   

    return(
       <div>
            <div className= {styles.sidebar}>

                <div className='top_section'>
                    <h2>Hello!</h2>
                    <h2>Welcome Back</h2>   
                </div>
                <div className={styles.contentscontainer}>
                    <ul className={styles.ui}>
                        <li className={styles.li}>
                       <img src={home}/><Link className={styles.a} to="/home">Home</Link>
                        </li>

                        <li className={styles.li}>
                        <img src={eye}/><Link className={styles.a} to="/viewstudents">View Students</Link>
                        </li>

                        <li className={styles.li}>
                        <img src={place}/> <Link className={styles.a} to="/placement">Placement History</Link>
                        </li>

                        <li className={styles.li}>
                        <img  id={styles.log} src={log}/><Link   onClick={logout} className={styles.a} id={styles.logout}> Logout</Link>
                        </li>

                    </ul>
                </div>

               
            
            
            </div>
            <div className={styles.side}>
                    <ul className={styles.ui}>
                        <li className={styles.li}>
                       <Link to="/home"><img src={home}/></Link>
                        </li>

                        <li className={styles.li}>
                        <Link  to="/viewstudents"><img src={eye}/></Link>
                        </li>

                        <li className={styles.li}>
                         <Link to="/placement"><img src={place}/></Link>
                        </li>

                        <li className={styles.li}>
                        <Link   to="/placement"><img  id={styles.log} src={log}/></Link>
                        </li>

                    </ul>
                </div>

           
         </div>


           
    );
    
};

export default SideBar;