import { useState } from "react"
import { Outlet,Navigate } from "react-router-dom"


const PrivateRoute=()=>{
    const localdata = JSON.parse(localStorage.getItem("token"));
    let auth={
        'token': localStorage.getItem('token'),
        'type':localdata.type

    }
    let y = auth.token && auth.type=='ST'
    return(
        y?<Outlet/>:<Navigate to="/login" />
    )
}

export default PrivateRoute;

export function Type(){
    const localdata = JSON.parse(localStorage.getItem("token"));
    let auth={
        'token': localStorage.getItem('token'),
        'type':localdata.type

    }
    let x = auth.token && auth.type=='TPO'
   

    return(
        x?<Outlet/>:<Navigate to="/login" />
    )
}

export function TypeHod(){
    const localdata = JSON.parse(localStorage.getItem("token"));
    let auth={
        'token': localStorage.getItem('token'),
        'type':localdata.type

    }
    let z = auth.token && auth.type=='HOD'
   

    return(
        z?<Outlet/>:<Navigate to="/login" />
    )
}



