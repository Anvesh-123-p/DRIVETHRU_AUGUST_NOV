import React from 'react';
import styles from './ForgetPassword.module.css';
import 'bootstrap/dist/css/bootstrap.css';
import axios from "axios";
 
const ForgetPassword=()=>{
    return(
        <div>
            <div className={styles.box}> 
                <div className={styles.image}><img src="https://cdni.iconscout.com/illustration/premium/thumb/man-working-on-his-laptop-on-the-sofa-at-home-2511605-2131717.png" alt=""/></div>
            </div>

            
                <h1 className={styles.h1}>Forgot Your Password?</h1> 
            
          
            <form>
            <div className="mb-3">
              
              <label htmlFor="exampleInputEmail1" id={styles.label}  className="form-label" >Email</label>
              <input type="email" placeholder='Email' className="form-control border border-dark" id={styles.exampleInputEmail1}  onChange={(e)=>{emailChange(e)}} aria-describedby="emailHelp" required />
              <p className={styles.p}>Please enter your Registered email</p>
            </div>
            <button type="submit"  className={`btn btn-dark ${styles.button}`}>Submit</button>
            </form>
        </div>
    )
}

export default ForgetPassword;