import React, { useState,useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import {BsCheck, BsPersonCircle} from "react-icons/bs"
import { Modal,ModalHeader,ModalBody } from 'reactstrap';
import styles from"./Header.module.css"
import axios from "axios";
import { propTypes } from 'react-bootstrap/esm/Image';
import Dropdown from 'react-bootstrap/Dropdown';
import { useNavigate } from "react-router-dom";





const Header =(props)=>{  

    const[showForm,setShowForm]=useState(false);
    const [Company,setCompany]=useState('')
    const [Percentage,setPercentage]=useState('')
    const [Jd,setJd]=useState('')
    const[Email,setEmail]=useState('')
    const[date,setDate]=useState('')
    const[description,setDescription]=useState('')
    const[Ctc,setCtc]=useState()
    const[nr,setnr]=useState()
    const[prof,setprof]=useState('')
    let navigate=useNavigate()

    let logurl="http://127.0.0.1:8000/api/users/"
    useEffect(() => {
      if(localStorage.getItem('token')!=null){
        const localdata = JSON.parse(localStorage.getItem("token"));
        console.log(localdata.id)
        axios.get(logurl,{
            params:{
                "id":localdata.id
            }}).then(
                (response)=>{
                    console.log(response.data.data.first_name)
                    setprof(response.data.data.first_name)
                }


            )

       
      }
    
    },[])


   

    const company=(e)=>{
        
        setCompany(e.target.value)
    }

    const percentage=(e)=>{
        
        setPercentage(e.target.value)
    }

    const Rounds=(e)=>{
        
        setnr(e.target.value)
    }

    const email=(e)=>{
        
        setEmail(e.target.value)
    }
    const Upload=(e)=>{
        
        setJd(e.target.value)
    }
    const StartDate=(e)=>{
        setDate(e.target.value)
    }
    const ctc=(e)=>{
        console.log(e)
        setCtc(e.target.value)
    }
    const Description=(e)=>{
        console.log(e)
        setDescription(e.target.value)
    }


    let url="http://127.0.0.1:8000/api/drives/"
    const handleSubmit=(e)=>{

        let data={
            
            "company_name": Company,
            "email": Email,
            "ctc": Ctc,
            "num_of_rounds": nr,
            "description": description,
            "eligible_percentage": Percentage,
            "jd_link": Jd,
            "start_date": date,
            "status": "NS",
            "enrolled_students": []
        
    
     
    }
   
    
        console.log(data)
        axios.post(url,data).then(
            (response)=>{
                console.log(response.data)
       

      
                
              }
            
            ).catch((err) => console.log(err))
            
            
        

    }

    

    const handleClose=()=>{
        setShowForm(false);
    }
  

    const logout=()=>{
        localStorage.clear()
        setTimeout(() => {
            navigate('/login');
            }, 2000);

    }
  
   

    return(
        <div className={styles.maindiv}> 
         
            <Modal size='lg'
             isOpen={showForm}
            toggle={()=>setShowForm(true)}>
            <ModalHeader
            toggle={()=>setShowForm(false)}> 
            Add Drive   
            </ModalHeader>
            <ModalBody>
            <form className="form-inline " id="StudentModal" onSubmit={(e) => {
                handleSubmit(e);
            }}>
            <div class="row g-5 mb-3">
                <div class="col ">
                    <label>Company Name</label>
                    <input type="text" className={`form-control ${styles.input}`}  onChange = {(e)=>{company(e)}}  placeholder="Company name" aria-label="Company name"/>
                </div>
                <div class="col">
                <label>No of Round</label>
                    <input type="number" className={`form-control ${styles.input}`} onChange = {(e)=>{Rounds(e)}}  placeholder="No of Rounds" aria-label="No of Rounds"/>
                </div>
            
            </div>
            <div class="row g-5 mb-3">
                <div class="col ">
                <label>Eligibilty Percentage</label>
                    <input type="number" className={`form-control ${styles.input}`}  onChange = {(e)=>{percentage(e)}} placeholder="Eligibility Percentage" aria-label="Eligibility Percentage"/>
                </div>
                <div class="col">
                <label>Email</label>
                    <input type="email" className={`form-control ${styles.input}`}  onChange = {(e)=>{email(e)}} placeholder="Round 2" aria-label="Email"/>
                </div>
            </div>
            <div class="row g-5 mb-3 ">
                <div class="col ">
                <label>Upload Jd</label>
                    <input type="text" class={`form-control ${styles.input}`} onChange = {(e)=>{Upload(e)}} placeholder="Upload JD" aria-label="Upload Jd"/>
                </div>
                <div class="col ">
                <label>Start Date</label>
                    <input type="date" class={`form-control ${styles.input}`}  onChange = {(e)=>{StartDate(e)}} placeholder="Round 3" aria-label="Round 3"/>
                </div>
            </div>
            <div class="row g-5 mb-3 ">
                <div class="col-lg-6 ">
                <label>CTC</label>
                    <input type="number" class={`form-control ${styles.input}`} onChange = {(e)=>{ctc(e)}} placeholder="CTC" aria-label="CTC"/>
                </div>    
            </div>
            <div class="row g-5 mb-3">
            <div class="col-lg-6">
                <label>Description</label>
                    <textarea type="text" className={`form-control ${styles.textarea}`} onChange = {(e)=>{Description(e)}} placeholder="Description" rows="5" maxLength={70} aria-label="Description"/>
                </div>
                
            </div>
            <button className={styles.button} onClick={handleClose} >Submit</button>
       
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
        
        </form>  
            </ModalBody>

        </Modal>
        <header >
            <nav className="navbar navbar-expand-lg navbar-light bg-light shadow bg-white rounded">
                <div className="container-fluid">
                  <a className="navbar-brand" id={styles.tpo} href="#">TPO Dashboard</a>
                  <div className={styles.nav}>
                  <button class="btn text-white" id={styles.postbtn} onClick={()=>setShowForm(true)} role="button">Post Drive</button>
                  <Dropdown>
                        <Dropdown.Toggle  id={styles.dropdownbasic}>
                            {prof}
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                            <Dropdown.Item href="#/action-1">Edit Profile</Dropdown.Item>
                            <Dropdown.Item onClick={logout}>Logout</Dropdown.Item>
                        </Dropdown.Menu>
                 </Dropdown>
                 </div>
                </div>

            </nav>
        </header>
       
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    </div>

    );
};

export default Header;