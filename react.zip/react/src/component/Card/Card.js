import React from "react";
import{Link} from 'react-router-dom'
import styles from'./Card.module.css'


const Card=(props)=>{

  const round={
    "state1": props.id
  }
  
    

return(
  <div className={`card ${styles.card}`} >
              <div className="card-body">
                <h3 className="card-title">{props.title}</h3>
                  <p className="card-text">{props.info}</p>
                  <h6 className="card-text">CTC:{props.ctc}</h6>
                  <h6 className="card-text ">Eligibility:{props.elig}</h6>
                  {props.status=="NS"?(<Link to="/viewround" state={round} >View</Link>):props.status=="IP"?(<Link to="/viewround" state={round} >View</Link>):(props.status=="CO" && <p>Completed</p>)}     
              </div>   
  </div>
)
}

export default Card;